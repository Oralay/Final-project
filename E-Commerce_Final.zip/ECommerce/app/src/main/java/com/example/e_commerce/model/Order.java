package com.example.e_commerce.model;

import java.util.HashSet;
import java.util.Set;

public class Order {
//set instead of list. the came course cannot be added twice
    public static Set<Integer> items_id = new HashSet<>();

}
